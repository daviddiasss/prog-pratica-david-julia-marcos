#include "CLinhasEquipotenciais.h"
