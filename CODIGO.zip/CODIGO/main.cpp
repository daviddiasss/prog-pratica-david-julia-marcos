#include <iostream>

#include "CSolverInfluxo.h"

int main() {
	CSolverInfluxo solver;
	solver.Simular();
}
