#include "CPosicaoAguaInjetada.h"

using namespace std;

vector <double> CPosicaoAguaInjetada::VazaoInjecao(double _krw, double _mw, double _dp, vector <double> _k, double _bw, double _comprimento, double _M, vector <double> _posicaoc, vector <double> _espessurac)
{
	
	return VazaoInj;
	
}

vector <double> CPosicaoAguaInjetada::PosicaoAguaInjetada(vector <double> _k,double _largura)
{
	
	return posicaoc;
	
}