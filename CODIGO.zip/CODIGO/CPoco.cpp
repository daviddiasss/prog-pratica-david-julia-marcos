#include "CPoco.h"

void CPoco::setX(double _x){
	
	x = _x;
	
}

void CPoco::setY(double _y){
	
	y = _y;
	
}

void CPoco::setC(double _c){
	
	c = _c;
	
}

void CPoco::setPi(double _pi){
	
	Pi = _pi;
	
}

double CPoco::getX(){
	
	return x;
	
}

double CPoco::getY(){
	
	return y;
	
}

double CPoco::getC(){
	
	return c;
	
}

double CPoco::getPi(){
	
	return Pi;
	
}
